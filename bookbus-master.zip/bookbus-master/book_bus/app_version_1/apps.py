from django.apps import AppConfig


class AppVersion1Config(AppConfig):
    name = 'app_version_1'
